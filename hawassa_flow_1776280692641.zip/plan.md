# Hierarchical Office Selection and Request Dispatch Restriction

## 1. Data Model Refinement
- Update `Config` logic to allow associating rooms with specific roles.
- In the UI, group the `rooms` by their associated `roles` to satisfy the "divided into two" / "properly separated" requirement.

## 2. Granular Office Selection UI
- Refactor the "Select Target Office" dropdown in the dashboard table.
- Implement `<optgroup>` in the `<select>` element to group offices (rooms) under their respective departments (roles).
- Example: 
  - Record
    - Office 101
    - Office 102
  - Finance
    - Counter A
    - Counter B

## 3. Role-Based Dispatch Restriction
- Add logic to the "Send" button in the dashboard table:
  - If `currentUser` is NOT an 'Admin':
    - The "Send" button and office selection dropdown should be `disabled` if the request's current `stage` (Role) is not one of the `currentUser.roles`.
    - This ensures non-admins can only dispatch requests that are currently in their queue.
  - If `currentUser` is an 'Admin', they can dispatch any request regardless of its current stage.

## 4. Visual Feedback
- Add a visual indicator (e.g., a "Lock" icon or dimmed row) when a non-admin user cannot interact with a request.
- Ensure tooltips or clear labels explain the restriction.

## 5. Verification
- Test with 'Admin' role to ensure full control.
- Test with staff roles (e.g., 'Record') to ensure they can only send requests at their stage and see granular office options.
- Validate build and ensure no regressions.
